import "./App.css";
// import "./components/PersonCard";
import PersonCard from "./components/PersonCard";

function App() {
  return (
    <div className="App">
      <PersonCard firstName={"Jane"} lastName={"Doe"} age={45} hairColor={"Black"} />
      <PersonCard firstName={"John"} lastName={"Smith"} age={88} hairColor={"Grey"} />
    </div>
  );
}

export default App;
